# Auditoria de Presupuestos - Interiorismo Retail Colombia

App web para auditar presupuestos de obra civil en formato Excel.

## Despliegue en Vercel (paso a paso)

### Opcion A - Sin codigo (mas facil)

1. Descarga esta carpeta como ZIP
2. Ve a https://vercel.com y crea una cuenta (gratis)
3. En el dashboard haz clic en "Add New Project"
4. Arrastra la carpeta del proyecto o seleccionala
5. Vercel detecta automaticamente que es Vite + React
6. Haz clic en "Deploy"
7. En ~1 minuto tienes tu URL: `https://auditoria-presupuestos.vercel.app`

### Opcion B - Con GitHub (recomendado para actualizaciones)

1. Crea cuenta en github.com
2. Crea repositorio nuevo llamado `auditoria-presupuestos`
3. Sube estos archivos al repositorio
4. Ve a vercel.com > "Add New Project" > "Import Git Repository"
5. Selecciona el repositorio
6. Deploy automatico

Cada vez que actualices el codigo en GitHub, Vercel re-despliega automaticamente.

## Estructura del proyecto

```
auditoria-presupuestos/
  index.html          <- entrada HTML
  vite.config.js      <- configuracion Vite
  package.json        <- dependencias
  vercel.json         <- configuracion Vercel
  src/
    main.jsx          <- punto de entrada React
    App.jsx           <- toda la logica de la app
```

## Uso

1. Abre la URL en cualquier dispositivo (celular, tablet, PC)
2. Carga tu archivo Excel (.xlsx) de presupuesto
3. Selecciona la hoja "Obra Civil"
4. Elige region y tipo de proyecto
5. La app detecta automaticamente:
   - Errores de formulacion (VU x Factor != V.con AIU)
   - Subtotales incorrectos (Cant x V.AIU != Subtotal)
   - Valores absurdos (miles de millones donde no corresponde)
   - Valores en columnas extra
   - Factores AIU fuera del rango de mercado Colombia
6. Descarga el Excel con los errores marcados

## Dependencias

- React 18
- Vite 5
- SheetJS (xlsx) para leer y generar Excel
