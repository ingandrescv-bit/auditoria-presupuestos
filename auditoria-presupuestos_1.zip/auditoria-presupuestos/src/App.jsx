import { useState, useRef, useCallback } from "react";
import * as XLSX from "xlsx";

const MAX_ABS = 50_000_000_000;
const AREA_M2 = 858.35;
const EXPECTED_COLS = 8; // cols 0-7 are the real data

const COP = n => n == null ? "--" : new Intl.NumberFormat("es-CO", {
  style: "currency", currency: "COP", maximumFractionDigits: 0
}).format(n);
const PCT = f => f == null ? "--" : ((f - 1) * 100).toFixed(1) + "%";

function toNum(val) {
  if (val == null || val === "") return null;
  if (typeof val === "number") return isFinite(val) ? val : null;
  const s = String(val).replace(/\s/g,"").replace(/\./g,"").replace(",",".");
  const n = parseFloat(s.replace(/[^0-9.-]/g,""));
  return isNaN(n) ? null : n;
}

function chk(a, b, res) {
  if (!a || !b || res == null) return null;
  const esp = a * b;
  const diff = Math.abs(esp - res);
  return diff > Math.max(Math.abs(esp) * 0.02, 500) ? { esp, diff } : null;
}

const AIU_REF = {
  bogota:   { retail_mediano:{min:1.08,max:1.18}, retail_grande:{min:1.07,max:1.15}, oficinas:{min:1.09,max:1.18} },
  medellin: { retail_mediano:{min:1.09,max:1.19}, retail_grande:{min:1.08,max:1.16}, oficinas:{min:1.10,max:1.20} },
  cali:     { retail_mediano:{min:1.09,max:1.20}, retail_grande:{min:1.08,max:1.17}, oficinas:{min:1.10,max:1.20} },
  otras:    { retail_mediano:{min:1.10,max:1.22}, retail_grande:{min:1.09,max:1.20}, oficinas:{min:1.11,max:1.22} },
};

function evalAIU(fac, region, tipo) {
  const ref = AIU_REF[region]?.[tipo];
  if (!ref || !fac) return null;
  if (fac < ref.min) return { nivel:"bajo", texto:"Factor " + PCT(fac) + " bajo (ref: " + PCT(ref.min) + "-" + PCT(ref.max) + ")" };
  if (fac > ref.max) return { nivel:"alto", texto:"Factor " + PCT(fac) + " alto (ref: " + PCT(ref.min) + "-" + PCT(ref.max) + ")" };
  return { nivel:"ok", texto:"En rango" };
}

// -- AUDITORIA PRINCIPAL ---------------------------------------
function auditarHoja(ws, region, tipo) {
  const datos = XLSX.utils.sheet_to_json(ws, { header:1, defval:null });
  const partidas=[], errores=[], alertasAIU=[];
  let capitulo=null, totalCalc=0;

  // Detecta cuantas columnas tiene realmente la hoja
  const maxCols = Math.max(...datos.map(r => r ? r.length : 0));

  // Fila de encabezado
  let fh=0;
  for (let i=0; i<Math.min(datos.length,6); i++) {
    if (datos[i] && String(datos[i][0]||"").toLowerCase().includes("item")) { fh=i; break; }
  }

  for (let i=fh+1; i<datos.length; i++) {
    const f = datos[i];
    if (!f || f.every(c=>c==null||String(c).trim()==="")) continue;

    const desc   = String(f[1]||"").trim();
    const cant   = toNum(f[3]);
    const vu     = toNum(f[4]);
    const fac    = toNum(f[5]);
    const vcAIU  = toNum(f[6]);
    const sub    = toNum(f[7]);

    if (!desc) continue;
    const dl = desc.toLowerCase();

    // -- Detecta valores en columnas fuera del rango esperado --
    for (let c=EXPECTED_COLS; c<maxCols; c++) {
      const v = toNum(f[c]);
      if (v != null && Math.abs(v) > 1000) {
        errores.push({
          fila: i+1, col: c, desc: desc.substring(0,80),
          tipo: "Valor en columna extra (col " + (c+1) + ")",
          detalle: "Columna " + (c+1) + " tiene valor " + COP(v) + " - no deberia tener datos aqui.",
          valorMal: v, valorCorrecto: null,
          diff: Math.abs(v), severidad:"alta",
          celdas: [{ fila:i+1, col:c, tipo:"extra" }]
        });
      }
    }

    // Es capitulo/seccion sin VU real
    const esCapitulo = (!vu || vu < 50) && (!cant || cant < 100);
    if (esCapitulo) {
      if (!dl.includes("subtotal") && desc.length>3) capitulo = desc.replace(/^\s+/,"");
      // Subtotal de capitulo absurdo
      if (sub!=null && Math.abs(sub)>MAX_ABS) {
        errores.push({
          fila:i+1, col:7, desc:desc.substring(0,80),
          tipo:"Subtotal de capitulo absurdo",
          detalle:"Subtotal del capitulo = " + COP(sub) + " - arrastrado por error en una partida interna.",
          valorMal: sub, valorCorrecto:null,
          diff: sub, severidad:"critica",
          celdas:[{fila:i+1,col:7,tipo:"absurdo"}]
        });
      }
      continue;
    }

    if (!vu || vu<100) continue;

    // -- Error: subtotal absurdo en partida --
    const subAbsurdo = sub!=null && Math.abs(sub)>MAX_ABS;
    if (subAbsurdo) {
      const correcto = cant && vcAIU ? cant*vcAIU : null;
      errores.push({
        fila:i+1, col:7, desc:desc.substring(0,80),
        tipo:"Subtotal absurdo",
        detalle:"Dice " + COP(sub) + " - deberia ser " + COP(correcto),
        valorMal:sub, valorCorrecto:correcto,
        diff: Math.abs((correcto||0)-sub), severidad:"critica",
        celdas:[{fila:i+1,col:7,tipo:"absurdo"}]
      });
    }

    // -- Error: VU x factor != V.con AIU --
    const errVC = fac&&vcAIU ? chk(vu,fac,vcAIU) : null;
    if (errVC) {
      errores.push({
        fila:i+1, col:6, desc:desc.substring(0,80),
        tipo:"V. con AIU incorrecto",
        detalle:COP(vu)+" x "+fac+" = "+COP(errVC.esp)+" pero dice "+COP(vcAIU),
        valorMal:vcAIU, valorCorrecto:errVC.esp,
        diff:errVC.diff, severidad:"alta",
        celdas:[{fila:i+1,col:6,tipo:"formula"}]
      });
    }

    // -- Error: cant x V.AIU != subtotal --
    const errSub = !subAbsurdo && cant&&vcAIU&&sub ? chk(cant,vcAIU,sub) : null;
    if (errSub) {
      errores.push({
        fila:i+1, col:7, desc:desc.substring(0,80),
        tipo:"Subtotal incorrecto",
        detalle:cant+" x "+COP(vcAIU)+" = "+COP(errSub.esp)+" pero dice "+COP(sub),
        valorMal:sub, valorCorrecto:errSub.esp,
        diff:errSub.diff, severidad:"alta",
        celdas:[{fila:i+1,col:7,tipo:"formula"}]
      });
    }

    // AIU atipico
    const evAIU = fac&&fac>1 ? evalAIU(fac,region,tipo) : null;
    if (evAIU&&evAIU.nivel!=="ok") alertasAIU.push({fila:i+1,desc:desc.substring(0,80),fac,nivel:evAIU.nivel,texto:evAIU.texto});

    if (!subAbsurdo) totalCalc += sub||0;
    partidas.push({fila:i+1,capitulo,desc,cant,vu,fac,vcAIU,sub,subAbsurdo,errVC,errSub,evAIU});
  }

  const factores = [...new Set(partidas.filter(p=>p.fac&&p.fac>1).map(p=>p.fac))].sort();
  const criticos = errores.filter(e=>e.severidad==="critica").length;
  const puntaje = Math.max(0, 100 - criticos*30 - errores.filter(e=>e.severidad==="alta").length*15 - alertasAIU.length*5);

  return { totalCalc, partidas, errores, alertasAIU, factores, puntaje, datos, maxCols };
}

// -- EXPORTAR EXCEL MARCADO ------------------------------------
function hex2argb(hex) { return "FF" + hex.replace("#",""); }

// Aplica fondo y fuente a una celda via styles en el objeto ws de SheetJS
function setCellStyle(ws, addr, bgHex, fontColor, bold) {
  if (!ws[addr]) ws[addr] = { t:"z", v:"" };
  ws[addr].s = {
    fill: { patternType:"solid", fgColor:{ rgb: hex2argb(bgHex) }, bgColor:{ indexed:64 } },
    font: { bold: bold||false, color:{ rgb: hex2argb(fontColor||"000000") } },
    alignment: { vertical:"center", wrapText: true }
  };
}

function exportarExcelMarcado(datos, errores, nombreHoja) {
  try {
    // Mapea errores por fila para acceso rapido
    // errores[i] donde i es indice 0-based del array datos
    const errMap = {};
    errores.forEach(e => {
      const ri = e.fila - 1; // fila 1-based -> 0-based
      if (!errMap[ri]) errMap[ri] = [];
      errMap[ri].push(e);
    });

    // Construye el array de datos:
    // - Mantiene las 8 columnas originales EXACTAS (cols 0-7)
    // - Agrega col 8: "AUDITORIA - ERROR DETECTADO"
    // - Agrega col 9: "VALOR CORRECTO"
    const aoa = datos.map((fila, ri) => {
      // Solo las primeras 8 columnas originales
      const row = (fila || []).slice(0, 8);
      while (row.length < 8) row.push(null);

      const errsAqui = errMap[ri] || [];

      if (ri === 0) {
        // Encabezado
        row.push("AUDITORIA - ERROR DETECTADO", "VALOR CORRECTO");
      } else if (errsAqui.length > 0) {
        const msgs = errsAqui.map(e => e.msg || e.tipo).join(" | ");
        const correcto = errsAqui.find(e => e.correcto != null)?.correcto ?? null;
        row.push(msgs, correcto != null ? correcto : "Revisar");
      } else {
        row.push(null, null);
      }
      return row;
    });

    // Escribe la hoja usando SheetJS con estilos habilitados
    const wb = XLSX.utils.book_new();
    const ws = XLSX.utils.aoa_to_sheet(aoa);

    // Anchos de columna (respeta proporciones originales)
    ws["!cols"] = [
      {wch:12},  // A - ITEM
      {wch:55},  // B - Descripcion
      {wch:8},   // C - UM
      {wch:10},  // D - Cantidad
      {wch:16},  // E - V.Unitario
      {wch:8},   // F - Factor AIU
      {wch:16},  // G - V.con AIU
      {wch:20},  // H - Subtotal
      {wch:55},  // I - Auditoria
      {wch:20},  // J - Valor correcto
    ];

    // Congela primera fila
    ws["!freeze"] = { xSplit:0, ySplit:1, topLeftCell:"A2", activePane:"bottomLeft" };

    // -- Estilos --
    // Colores del semaforo
    const C_ROJO    = "#FF4444";  // absurdo - critico
    const C_NARANJA = "#FF8C00";  // formula errada
    const C_AMARILLO= "#FFD700";  // columna extra
    const C_HEAD    = "#1C1B2E";  // encabezado oscuro
    const C_CAP     = "#2D2B4E";  // capitulo
    const C_SUB     = "#EDE9FE";  // subtotal
    const C_EVEN    = "#F9F8F5";  // filas pares

    // Estilo encabezado fila 1
    for (let c = 0; c < 10; c++) {
      const addr = XLSX.utils.encode_cell({r:0, c});
      setCellStyle(ws, addr, C_HEAD, "#FFFFFF", true);
    }

    // Estilos por fila de datos
    aoa.forEach((row, ri) => {
      if (ri === 0) return;
      const desc = String(datos[ri]?.[1] || "").toLowerCase();
      const item = String(datos[ri]?.[0] || "");
      const vu   = datos[ri]?.[4];
      const errsAqui = errMap[ri] || [];

      const esCapitulo = (!vu || parseFloat(vu) < 50) && item && !item.includes(",") && desc.length > 3 && !desc.includes("subtotal");
      const esSubtotal = desc.includes("subtotal") || desc.includes("total");

      // Estilo base de cada celda de las 8 columnas originales
      for (let c = 0; c < 8; c++) {
        const addr = XLSX.utils.encode_cell({r:ri, c});
        if (!ws[addr]) ws[addr] = {t:"z", v:""};
        let bg = ri % 2 === 0 ? C_EVEN : "#FFFFFF";
        let fg = "#1C1B2E";
        let bold = false;
        if (esCapitulo) { bg = C_CAP; fg = "#FFFFFF"; bold = true; }
        else if (esSubtotal) { bg = C_SUB; bold = true; }
        setCellStyle(ws, addr, bg, fg, bold);
      }

      // Semaforo: colorea SOLO las celdas con error
      errsAqui.forEach(e => {
        const addr = XLSX.utils.encode_cell({r:ri, c:e.col});
        if (!ws[addr]) ws[addr] = {t:"z", v:""};
        let bg, fg;
        if (e.tipo === "absurdo") { bg = C_ROJO; fg = "#FFFFFF"; }
        else if (e.tipo === "formula") { bg = C_NARANJA; fg = "#FFFFFF"; }
        else { bg = C_AMARILLO; fg = "#1a1a1a"; }
        setCellStyle(ws, addr, bg, fg, true);
      });

      // Columna auditoria (col 8)
      if (errsAqui.length > 0) {
        const addr8 = XLSX.utils.encode_cell({r:ri, c:8});
        if (!ws[addr8]) ws[addr8] = {t:"z", v:""};
        const maxTipo = errsAqui.some(e=>e.tipo==="absurdo") ? "absurdo"
                      : errsAqui.some(e=>e.tipo==="formula") ? "formula" : "extra";
        const bg = maxTipo==="absurdo" ? C_ROJO : maxTipo==="formula" ? C_NARANJA : C_AMARILLO;
        const fg = maxTipo==="extra" ? "#1a1a1a" : "#FFFFFF";
        setCellStyle(ws, addr8, bg, fg, true);
        // Columna valor correcto
        const addr9 = XLSX.utils.encode_cell({r:ri, c:9});
        if (!ws[addr9]) ws[addr9] = {t:"z", v:""};
        setCellStyle(ws, addr9, "#D1FAE5", "#065f46", true);
      }
    });

    // -- Leyenda del semaforo al pie --
    const lastRow = aoa.length + 2;
    const leyenda = [
      [null, "SEMAFORO DE ERRORES", null],
      [null, "ROJO  - Subtotal absurdo (valor imposible, error grave de digitacion)", null],
      [null, "NARANJA - Error de formula (VU x Factor != V.AIU  o  Cant x V.AIU != Subtotal)", null],
      [null, "AMARILLO - Valor en columna extra (dato donde no deberia haber)", null],
    ];
    leyenda.forEach((ley, li) => {
      const ri = lastRow + li;
      ley.forEach((v, ci) => {
        const addr = XLSX.utils.encode_cell({r:ri, c:ci});
        if (v) {
          ws[addr] = {t:"s", v};
          const colors = [null, C_HEAD, C_ROJO, C_NARANJA, C_AMARILLO];
          const bg = colors[li] || C_HEAD;
          setCellStyle(ws, addr, bg, "#FFFFFF", true);
        }
      });
    });

    // Actualiza rango de la hoja para incluir leyenda
    const totalRows = lastRow + leyenda.length;
    ws["!ref"] = XLSX.utils.encode_range({s:{r:0,c:0}, e:{r:totalRows, c:9}});

    XLSX.utils.book_append_sheet(wb, ws, (nombreHoja||"Obra Civil").substring(0,31));

    // Descarga compatible iOS / Android / Desktop
    const wbOut = XLSX.write(wb, { bookType:"xlsx", type:"array", cellStyles:true });
    const blob = new Blob([wbOut], { type:"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "Auditoria_" + (nombreHoja||"ObraCivil").replace(/\s/g,"_") + ".xlsx";
    document.body.appendChild(a);
    a.click();
    setTimeout(() => { document.body.removeChild(a); URL.revokeObjectURL(url); }, 500);
  } catch(err) {
    alert("Error al generar el archivo: " + err.message);
  }
}
function leerWb(file) {
  return new Promise((res,rej)=>{
    const r=new FileReader();
    r.onload=e=>{try{res(XLSX.read(new Uint8Array(e.target.result),{type:"array"}));}catch{rej(new Error("No se pudo leer el archivo."));}};
    r.onerror=()=>rej(new Error("Error leyendo."));
    r.readAsArrayBuffer(file);
  });
}

async function leerSheets(url) {
  const m=url.match(/\/d\/([a-zA-Z0-9_-]{20,})/);
  if(!m) throw new Error("Link invalido.");
  const resp=await fetch("https://docs.google.com/spreadsheets/d/"+m[1]+"/export?format=xlsx");
  if(resp.status===403) throw new Error("Acceso denegado. Compartir como 'Cualquiera con el link puede ver'.");
  if(!resp.ok) throw new Error("Error "+resp.status);
  return XLSX.read(new Uint8Array(await resp.arrayBuffer()),{type:"array"});
}

// -- UI --------------------------------------------------------
const C={bg:"#F5F3EF",dark:"#1C1B2E",accent:"#8B7CF8",accentL:"#EDE9FE",white:"#FFFFFF",border:"#E8E4DC",text:"#1C1B2E",muted:"#7C7B8A",red:"#dc2626",redL:"#fef2f2",green:"#059669",greenL:"#d1fae5"};

function KPI({label,value,sub,ok,accent}){
  const col=ok===true?C.green:ok===false?C.red:accent?C.accent:C.text;
  return(
    <div style={{background:C.white,borderRadius:12,padding:"12px 14px",flex:1,minWidth:120,border:"1px solid "+C.border,flexShrink:0}}>
      <div style={{fontSize:9,color:C.muted,fontWeight:700,letterSpacing:1,marginBottom:4}}>{label}</div>
      <div style={{fontSize:17,fontWeight:800,color:col,lineHeight:1.1}}>{value}</div>
      {sub&&<div style={{fontSize:10,color:C.muted,marginTop:3}}>{sub}</div>}
    </div>
  );
}

function Badge({label,bg,fg}){
  return <span style={{background:bg,color:fg,borderRadius:20,padding:"3px 10px",fontSize:11,fontWeight:700,whiteSpace:"nowrap"}}>{label}</span>;
}

export default function App(){
  const [paso,setPaso]=useState("entrada");
  const [link,setLink]=useState("");
  const [loading,setLoading]=useState(false);
  const [loadMsg,setLoadMsg]=useState("");
  const [err,setErr]=useState("");
  const [wb,setWb]=useState(null);
  const [hojas,setHojas]=useState([]);
  const [hojaSel,setHojaSel]=useState("");
  const [region,setRegion]=useState("bogota");
  const [tipo,setTipo]=useState("retail_mediano");
  const [res,setRes]=useState(null);
  const [tab,setTab]=useState("errores");
  const [soloErr,setSoloErr]=useState(false);
  const [dragging,setDragging]=useState(false);
  const inputRef=useRef(null);

  const reset=()=>{setWb(null);setHojas([]);setHojaSel("");setRes(null);setErr("");setLink("");setPaso("entrada");};

  const cargar=useCallback(async fuente=>{
    setLoading(true);setErr("");
    try{
      let w;
      if(typeof fuente==="string"){setLoadMsg("Descargando...");w=await leerSheets(fuente);}
      else{setLoadMsg("Leyendo archivo...");w=await leerWb(fuente);}
      setWb(w);setHojas(w.SheetNames);
      const oc=w.SheetNames.find(n=>n.toLowerCase().replace(/\s/g,"").includes("obracivil")&&!n.toLowerCase().includes("demol"))||w.SheetNames[0];
      setHojaSel(oc);setPaso("config");
    }catch(e){setErr(e.message);}
    setLoading(false);setLoadMsg("");
  },[]);

  const auditar=useCallback(()=>{
    if(!hojaSel){setErr("Selecciona una hoja.");return;}
    setLoading(true);setLoadMsg("Analizando...");
    setTimeout(()=>{
      try{
        const r=auditarHoja(wb.Sheets[hojaSel],region,tipo);
        setRes({...r,hojaNombre:hojaSel});
        setTab(r.errores.length>0?"errores":"tabla");
        setPaso("resultado");
      }catch(e){setErr(e.message);}
      setLoading(false);setLoadMsg("");
    },80);
  },[wb,hojaSel,region,tipo]);

  const onDrop=useCallback(e=>{e.preventDefault();setDragging(false);const f=e.dataTransfer.files[0];if(f)cargar(f);},[cargar]);

  // -- RESULTADO --------------------------------------------
  if(paso==="resultado"&&res){
    const {totalCalc,partidas,errores,alertasAIU,factores,puntaje,datos,hojaNombre}=res;
    const criticos=errores.filter(e=>e.severidad==="critica");
    const altos=errores.filter(e=>e.severidad==="alta");
    const mostrar=soloErr?partidas.filter(p=>p.errVC||p.errSub||p.subAbsurdo||(p.evAIU&&p.evAIU.nivel!=="ok")):partidas;

    // m2 por capitulo
    const capMap={};
    partidas.forEach(p=>{
      if(p.subAbsurdo)return;
      const k=p.capitulo||"Sin capitulo";
      if(!capMap[k])capMap[k]={total:0,count:0};
      capMap[k].total+=p.sub||0;capMap[k].count+=1;
    });
    const caps=Object.entries(capMap).map(([k,v])=>({nombre:k,...v})).sort((a,b)=>b.total-a.total);
    const totalCaps=caps.reduce((s,c)=>s+c.total,0);

    return(
      <div style={{fontFamily:"'Inter',system-ui,sans-serif",background:C.bg,minHeight:"100vh",display:"flex",flexDirection:"column",maxWidth:700,margin:"0 auto"}}>

        {/* Header */}
        <div style={{background:C.dark,padding:"12px 16px",display:"flex",alignItems:"center",gap:10}}>
          <button onClick={reset} style={{background:"transparent",border:"1px solid #ffffff22",color:"#9ca3af",borderRadius:8,padding:"5px 12px",cursor:"pointer",fontSize:12,flexShrink:0}}>Volver</button>
          <div style={{flex:1,minWidth:0}}>
            <div style={{fontSize:8,color:"#8B7CF8",letterSpacing:2,fontWeight:700}}>AUDITORIA - {hojaNombre.toUpperCase()}</div>
            <div style={{color:"white",fontSize:14,fontWeight:800}}>La Riviera - CC El Retiro</div>
          </div>
          <div style={{background:puntaje>=80?C.greenL:puntaje>=60?"#fef3c7":"#fce7f3",color:puntaje>=80?"#065f46":puntaje>=60?"#92400e":C.red,borderRadius:8,padding:"5px 12px",fontWeight:800,fontSize:15,flexShrink:0}}>
            {puntaje}/100
          </div>
        </div>

        {/* Alerta critica */}
        {criticos.length>0&&(
          <div style={{background:"#fef2f2",borderLeft:"4px solid "+C.red,padding:"10px 16px"}}>
            <div style={{fontWeight:800,color:C.red,fontSize:13,marginBottom:4}}>{criticos.length+" ERROR(ES) CRITICO(S)"}</div>
            {criticos.map((e,i)=>(
              <div key={i} style={{fontSize:11,color:"#7f1d1d"}}>{"Fila "+e.fila+": "+e.desc.substring(0,55)+"..."}</div>
            ))}
          </div>
        )}

        {/* KPIs */}
        <div style={{padding:"10px 16px",display:"flex",gap:8,overflowX:"auto",borderBottom:"1px solid "+C.border,background:C.white}}>
          <KPI label="TOTAL CALC." value={COP(totalCalc)} sub="sin filas absurdas" ok={null}/>
          <KPI label="ERRORES CRITICOS" value={criticos.length} sub={altos.length+" errores formula"} ok={criticos.length===0&&altos.length===0}/>
          <KPI label="ALERTAS AIU" value={alertasAIU.length} sub="factores atipicos" ok={alertasAIU.length===0}/>
          <KPI label="COSTO/m2" value={COP(Math.round(totalCalc/AREA_M2))} sub={AREA_M2+"m2"} accent/>
        </div>

        {/* Boton exportar */}
        <div style={{padding:"8px 16px",background:C.white,borderBottom:"1px solid "+C.border,display:"flex",justifyContent:"flex-end"}}>
          <button onClick={()=>exportarExcelMarcado(datos,errores,hojaNombre)}
            style={{background:C.accent,color:"white",border:"none",borderRadius:10,padding:"9px 18px",fontWeight:700,cursor:"pointer",fontSize:13}}>
            Descargar Excel con errores marcados
          </button>
        </div>

        {/* Tabs */}
        <div style={{background:C.white,borderBottom:"1px solid "+C.border,display:"flex",overflowX:"auto"}}>
          {[
            {id:"errores",label:"Errores ("+errores.length+")"},
            {id:"tabla",  label:"Partidas ("+partidas.length+")"},
            {id:"aiu",    label:"AIU + m2"},
          ].map(t=>(
            <button key={t.id} onClick={()=>setTab(t.id)}
              style={{padding:"10px 16px",border:"none",cursor:"pointer",fontSize:13,whiteSpace:"nowrap",flexShrink:0,fontWeight:tab===t.id?700:400,background:"transparent",color:tab===t.id?C.accent:C.muted,borderBottom:tab===t.id?"3px solid "+C.accent:"3px solid transparent"}}>
              {t.label}
            </button>
          ))}
        </div>

        {/* Contenido scrollable */}
        <div style={{flex:1,overflowY:"auto",padding:"14px 16px"}}>

          {/* TAB ERRORES */}
          {tab==="errores"&&(
            <div>
              {!errores.length?(
                <div style={{background:C.greenL,borderRadius:12,padding:"20px",color:"#065f46",fontWeight:700,textAlign:"center",fontSize:15}}>
                  Sin errores detectados
                </div>
              ):errores.map((e,i)=>(
                <div key={i} style={{background:C.white,borderRadius:12,border:"1px solid "+(e.severidad==="critica"?C.red:"#fecaca"),marginBottom:10,overflow:"hidden"}}>
                  <div style={{background:e.severidad==="critica"?C.red:"#fff1f2",padding:"9px 14px",display:"flex",justifyContent:"space-between",alignItems:"center",gap:8}}>
                    <div style={{fontWeight:700,color:e.severidad==="critica"?"white":C.red,fontSize:13}}>
                      {"Fila "+e.fila+" - "+e.tipo}
                    </div>
                    <Badge label={e.severidad.toUpperCase()} bg={e.severidad==="critica"?"#7f1d1d":"#fce7f3"} fg={e.severidad==="critica"?"white":C.red}/>
                  </div>
                  <div style={{padding:"10px 14px"}}>
                    <div style={{fontWeight:600,fontSize:12,color:C.text,marginBottom:6}}>{e.desc}</div>
                    <div style={{fontSize:12,color:C.red,fontFamily:"monospace",background:"#fff5f5",borderRadius:6,padding:"7px 10px",lineHeight:1.5}}>{e.detalle}</div>
                    {e.valorCorrecto!=null&&(
                      <div style={{marginTop:8,background:C.greenL,borderRadius:8,padding:"7px 10px",fontSize:12,color:"#065f46",fontWeight:600}}>
                        {"Valor correcto: "+COP(e.valorCorrecto)}
                      </div>
                    )}
                    <div style={{fontSize:11,color:C.muted,marginTop:6}}>{"Diferencia: "+COP(e.diff)+" | Columna "+(e.col+1)+" ("+XLSX.utils.encode_col(e.col)+")  Fila "+(e.fila)}</div>
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* TAB TABLA - tarjetas */}
          {tab==="tabla"&&(
            <div>
              <div style={{display:"flex",alignItems:"center",gap:10,marginBottom:10}}>
                <label style={{display:"flex",alignItems:"center",gap:8,fontSize:13,color:C.muted,cursor:"pointer"}} onClick={()=>setSoloErr(v=>!v)}>
                  <div style={{width:36,height:20,borderRadius:10,position:"relative",background:soloErr?C.accent:"#d1d5db",flexShrink:0}}>
                    <div style={{width:14,height:14,borderRadius:"50%",background:"white",position:"absolute",top:3,left:soloErr?19:3,transition:"left .2s"}}/>
                  </div>
                  Solo con errores
                </label>
                <span style={{fontSize:12,color:C.muted}}>{mostrar.length+"/"+partidas.length}</span>
              </div>
              {mostrar.map((p,i)=>{
                const hayErr=p.errVC||p.errSub||p.subAbsurdo;
                const hayAIU=p.evAIU&&p.evAIU.nivel!=="ok";
                return(
                  <div key={i} style={{background:C.white,borderRadius:12,border:"1px solid "+(p.subAbsurdo?C.red:hayErr?"#fecaca":hayAIU?"#fde68a":C.border),marginBottom:8,overflow:"hidden"}}>
                    <div style={{padding:"8px 12px",background:p.subAbsurdo?"#fef2f2":hayErr?"#fff1f2":hayAIU?"#fffbeb":"#FAFAF8",display:"flex",justifyContent:"space-between",alignItems:"flex-start"}}>
                      <div style={{flex:1}}>
                        {p.capitulo&&<div style={{fontSize:9,color:C.accent,fontWeight:700,marginBottom:1}}>{p.capitulo.substring(0,40)}</div>}
                        <div style={{fontWeight:600,fontSize:12,color:C.text,lineHeight:1.3}}>{p.desc.substring(0,75)}{p.desc.length>75?"...":""}</div>
                      </div>
                      <div style={{fontSize:10,color:C.muted,flexShrink:0,marginLeft:8}}>{"F"+p.fila}</div>
                    </div>
                    <div style={{padding:"8px 12px",display:"grid",gridTemplateColumns:"1fr 1fr 1fr",gap:6}}>
                      <div><div style={{fontSize:9,color:C.muted,fontWeight:700}}>CANT</div><div style={{fontSize:12,fontWeight:600,color:C.text}}>{p.cant+" "+p.um}</div></div>
                      <div><div style={{fontSize:9,color:C.muted,fontWeight:700}}>V.UNITARIO</div><div style={{fontSize:12,fontWeight:600,color:C.text}}>{COP(p.vu)}</div></div>
                      <div><div style={{fontSize:9,color:C.muted,fontWeight:700}}>FACTOR</div><div style={{fontSize:12,fontWeight:700,color:p.fac>1.15?C.red:p.fac<1.05?"#f59e0b":C.text}}>{"x"+(p.fac||"--")}</div></div>
                      <div><div style={{fontSize:9,color:C.muted,fontWeight:700}}>V.CON AIU</div><div style={{fontSize:12,fontWeight:600,color:p.errVC?C.red:C.text}}>{COP(p.vcAIU)}</div></div>
                      <div style={{gridColumn:"2/4"}}><div style={{fontSize:9,color:C.muted,fontWeight:700}}>SUBTOTAL</div><div style={{fontSize:13,fontWeight:800,color:p.subAbsurdo||p.errSub?C.red:C.accent}}>{COP(p.sub)}</div></div>
                    </div>
                    {(hayErr||hayAIU)&&(
                      <div style={{padding:"8px 12px",borderTop:"1px solid #fee2e2",background:"#fff5f5"}}>
                        {p.subAbsurdo&&<div style={{fontSize:11,color:C.red,fontWeight:700,marginBottom:3}}>SUBTOTAL ABSURDO - revisar digitacion</div>}
                        {p.errVC&&<div style={{fontSize:11,color:C.red,marginBottom:2}}>{"V.AIU correcto: "+COP(p.errVC.esp)}</div>}
                        {p.errSub&&<div style={{fontSize:11,color:C.red,marginBottom:2}}>{"Subtotal correcto: "+COP(p.errSub.esp)+" (diferencia "+COP(p.errSub.diff)+")"}</div>}
                        {hayAIU&&!hayErr&&<div style={{fontSize:11,color:"#92400e"}}>{p.evAIU.texto}</div>}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          )}

          {/* TAB AIU + m2 */}
          {tab==="aiu"&&(
            <div>
              {/* Factores */}
              <div style={{background:C.white,borderRadius:14,border:"1px solid "+C.border,padding:16,marginBottom:14}}>
                <div style={{fontWeight:700,fontSize:14,marginBottom:4,color:C.text}}>Factores AIU usados</div>
                <div style={{fontSize:11,color:C.muted,marginBottom:12}}>{"Referencia "+region+": "+PCT(AIU_REF[region]?.[tipo]?.min)+" a "+PCT(AIU_REF[region]?.[tipo]?.max)}}</div>
                <div style={{display:"flex",gap:8,flexWrap:"wrap",marginBottom:alertasAIU.length?12:0}}>
                  {factores.map(f=>{
                    const ev=evalAIU(f,region,tipo);
                    const bgc=ev?.nivel==="ok"?C.greenL:ev?.nivel==="bajo"?"#fce7f3":"#fff3cd";
                    const fgc=ev?.nivel==="ok"?"#065f46":ev?.nivel==="bajo"?"#be185d":"#92400e";
                    const cnt=partidas.filter(p=>p.fac===f).length;
                    return(
                      <div key={f} style={{background:bgc,borderRadius:10,padding:"10px 14px",textAlign:"center",minWidth:80}}>
                        <div style={{fontSize:18,fontWeight:800,color:fgc}}>{"x"+f}</div>
                        <div style={{fontSize:11,color:fgc,fontWeight:600}}>{PCT(f)}</div>
                        <div style={{fontSize:10,color:C.muted}}>{cnt+" items"}</div>
                        <div style={{fontSize:10,color:fgc,fontWeight:700}}>{ev?.nivel==="ok"?"OK":ev?.nivel==="bajo"?"BAJO":"ALTO"}</div>
                      </div>
                    );
                  })}
                </div>
                {alertasAIU.length>0&&(
                  <div style={{background:"#fff7ed",borderRadius:8,padding:"10px 12px"}}>
                    <div style={{fontWeight:700,fontSize:11,color:"#92400e",marginBottom:6}}>{alertasAIU.length+" partidas con factor atipico"}</div>
                    {alertasAIU.slice(0,4).map((a,i)=>(
                      <div key={i} style={{fontSize:11,color:C.muted,padding:"2px 0"}}>{"Fila "+a.fila+" x"+a.fac+" - "+a.desc.substring(0,40)}</div>
                    ))}
                  </div>
                )}
              </div>

              {/* m2 por capitulo */}
              <div style={{background:C.white,borderRadius:14,border:"1px solid "+C.border,padding:16,marginBottom:14}}>
                <div style={{fontWeight:700,fontSize:14,marginBottom:4,color:C.text}}>Valor por m2 por capitulo</div>
                <div style={{fontSize:11,color:C.muted,marginBottom:12}}>{"Area: "+AREA_M2.toLocaleString("es-CO")+" m2"}</div>
                {caps.map((c,i)=>{
                  const pct=totalCaps>0?(c.total/totalCaps*100):0;
                  const vm2=Math.round(c.total/AREA_M2);
                  return(
                    <div key={i} style={{marginBottom:12,paddingBottom:12,borderBottom:i<caps.length-1?"1px solid "+C.border:"none"}}>
                      <div style={{display:"flex",justifyContent:"space-between",alignItems:"baseline",marginBottom:3}}>
                        <div style={{fontWeight:600,fontSize:12,color:C.text,flex:1}}>{c.nombre.substring(0,45)}</div>
                        <div style={{fontWeight:800,fontSize:13,color:C.accent,marginLeft:8,whiteSpace:"nowrap"}}>{COP(vm2)+"/m2"}</div>
                      </div>
                      <div style={{height:5,background:C.accentL,borderRadius:3,marginBottom:4}}>
                        <div style={{height:5,background:C.accent,borderRadius:3,width:Math.min(Math.round(pct*2),100)+"%"}}/>
                      </div>
                      <div style={{display:"flex",justifyContent:"space-between",fontSize:10,color:C.muted}}>
                        <span>{COP(c.total)}</span>
                        <span>{pct.toFixed(1)+"% - "+c.count+" items"}</span>
                      </div>
                    </div>
                  );
                })}
                <div style={{background:"#f5f3ff",borderRadius:10,padding:"12px 14px",display:"flex",justifyContent:"space-between",alignItems:"center"}}>
                  <div>
                    <div style={{fontSize:10,color:C.muted,fontWeight:700}}>TOTAL</div>
                    <div style={{fontSize:15,fontWeight:800,color:C.text}}>{COP(totalCaps)}</div>
                  </div>
                  <div style={{textAlign:"right"}}>
                    <div style={{fontSize:10,color:C.muted,fontWeight:700}}>COSTO / m2</div>
                    <div style={{fontSize:20,fontWeight:800,color:C.accent}}>{COP(Math.round(totalCaps/AREA_M2))}</div>
                  </div>
                </div>
              </div>

              {/* Resumen */}
              <div style={{background:C.dark,borderRadius:14,padding:16}}>
                <div style={{fontWeight:700,fontSize:14,marginBottom:12,color:"white"}}>Resumen ejecutivo</div>
                <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10}}>
                  {[
                    {label:"Area",value:AREA_M2.toLocaleString("es-CO")+" m2"},
                    {label:"Costo directo/m2",value:COP(Math.round(totalCaps/AREA_M2))},
                    {label:"Capitulo mayor",value:(caps[0]?.nombre||"--").substring(0,22)},
                    {label:"m2 cap. principal",value:COP(Math.round((caps[0]?.total||0)/AREA_M2))},
                    {label:"Total + AIU 15%",value:COP(Math.round(totalCaps*1.15))},
                    {label:"Total/m2 + AIU",value:COP(Math.round(totalCaps*1.15/AREA_M2))},
                  ].map((k,i)=>(
                    <div key={i} style={{background:"rgba(255,255,255,0.1)",borderRadius:10,padding:"10px 12px"}}>
                      <div style={{fontSize:9,color:"#9ca3af",fontWeight:700,letterSpacing:1,marginBottom:3}}>{k.label.toUpperCase()}</div>
                      <div style={{fontSize:14,fontWeight:800,color:"white"}}>{k.value}</div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    );
  }

  // -- CONFIG -----------------------------------------------
  if(paso==="config") return(
    <div style={{fontFamily:"'Inter',system-ui,sans-serif",background:C.bg,minHeight:"100vh",maxWidth:600,margin:"0 auto"}}>
      <div style={{background:C.dark,padding:"20px"}}>
        <div style={{fontSize:9,color:"#8B7CF8",letterSpacing:2,fontWeight:700,marginBottom:5}}>CONFIGURACION</div>
        <h1 style={{color:"white",fontSize:20,fontWeight:800,margin:0}}>Configurar auditoria</h1>
      </div>
      <div style={{padding:"18px 16px",overflowY:"auto"}}>
        {err&&<div style={{background:C.redL,border:"1px solid #fecaca",borderRadius:10,padding:"12px",color:C.red,fontSize:13,marginBottom:14}}>{err}</div>}

        <div style={{fontWeight:700,fontSize:13,color:C.text,marginBottom:8}}>Hoja a auditar</div>
        <div style={{background:C.white,borderRadius:12,border:"1px solid "+C.border,overflow:"hidden",marginBottom:18}}>
          {hojas.map((n,i)=>(
            <div key={n} onClick={()=>setHojaSel(n)}
              style={{display:"flex",alignItems:"center",gap:12,padding:"13px 16px",borderBottom:i<hojas.length-1?"1px solid "+C.border:"none",cursor:"pointer",background:hojaSel===n?C.accentL:C.white}}>
              <div style={{width:20,height:20,borderRadius:5,border:"2px solid "+(hojaSel===n?C.accent:C.border),background:hojaSel===n?C.accent:"transparent",display:"flex",alignItems:"center",justifyContent:"center",flexShrink:0}}>
                {hojaSel===n&&<span style={{color:"white",fontSize:11,fontWeight:800}}>v</span>}
              </div>
              <span style={{fontWeight:600,fontSize:13,color:hojaSel===n?C.accent:C.text}}>{n}</span>
            </div>
          ))}
        </div>

        <div style={{fontWeight:700,fontSize:13,color:C.text,marginBottom:8}}>Region</div>
        <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:8,marginBottom:16}}>
          {[["bogota","Bogota D.C."],["medellin","Medellin"],["cali","Cali"],["otras","Otras"]].map(([v,l])=>(
            <button key={v} onClick={()=>setRegion(v)}
              style={{padding:"10px",borderRadius:10,border:"2px solid "+(region===v?C.accent:C.border),background:region===v?C.accentL:C.white,color:region===v?C.accent:C.text,fontWeight:region===v?700:400,cursor:"pointer",fontSize:13}}>
              {l}
            </button>
          ))}
        </div>

        <div style={{fontWeight:700,fontSize:13,color:C.text,marginBottom:8}}>Tipo de proyecto</div>
        <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:8,marginBottom:20}}>
          {[["retail_mediano","Retail 100-500m2"],["retail_grande","Retail +500m2"],["oficinas","Oficinas"]].map(([v,l])=>(
            <button key={v} onClick={()=>setTipo(v)}
              style={{padding:"10px",borderRadius:10,border:"2px solid "+(tipo===v?C.accent:C.border),background:tipo===v?C.accentL:C.white,color:tipo===v?C.accent:C.text,fontWeight:tipo===v?700:400,cursor:"pointer",fontSize:13}}>
              {l}
            </button>
          ))}
        </div>

        <div style={{display:"flex",gap:10}}>
          <button onClick={reset} style={{flex:1,padding:"13px",borderRadius:12,border:"1px solid "+C.border,background:C.white,color:C.muted,cursor:"pointer",fontSize:14,fontWeight:600}}>Volver</button>
          <button onClick={auditar} disabled={!hojaSel||loading}
            style={{flex:2,padding:"13px",borderRadius:12,border:"none",background:hojaSel?C.accent:"#d1d5db",color:"white",cursor:hojaSel?"pointer":"not-allowed",fontSize:14,fontWeight:700}}>
            {loading?"Analizando...":"Auditar presupuesto"}
          </button>
        </div>
      </div>
    </div>
  );

  // -- ENTRADA ----------------------------------------------
  return(
    <div style={{fontFamily:"'Inter',system-ui,sans-serif",background:C.bg,minHeight:"100vh",display:"flex",flexDirection:"column",maxWidth:600,margin:"0 auto"}}>
      <div style={{background:C.dark,padding:"24px 20px"}}>
        <div style={{fontSize:9,color:"#8B7CF8",letterSpacing:2,fontWeight:700,marginBottom:6}}>INTERIORISMO RETAIL - COLOMBIA</div>
        <h1 style={{color:"white",fontSize:22,fontWeight:800,margin:0}}>Auditoria de Presupuestos</h1>
        <p style={{color:"#6b7280",fontSize:13,margin:"6px 0 0"}}>Carga el Excel o pega el link de Google Sheets</p>
      </div>
      <div style={{flex:1,padding:"20px 16px"}}>
        {err&&<div style={{background:C.redL,border:"1px solid #fecaca",borderRadius:12,padding:"14px",color:C.red,fontSize:13,marginBottom:16,lineHeight:1.5}}>{err}</div>}
        {loading?(
          <div style={{background:C.white,borderRadius:16,border:"1px solid "+C.border,padding:48,textAlign:"center"}}>
            <div style={{width:44,height:44,border:"3px solid "+C.accentL,borderTopColor:C.accent,borderRadius:"50%",animation:"spin 1s linear infinite",margin:"0 auto 16px"}}/>
            <div style={{fontWeight:700,fontSize:15,color:C.text}}>{loadMsg}</div>
          </div>
        ):(
          <>
            <div style={{background:C.white,borderRadius:14,border:"1px solid "+C.border,padding:18,marginBottom:12}}>
              <div style={{fontWeight:700,fontSize:14,color:C.text,marginBottom:4}}>Link de Google Sheets</div>
              <p style={{fontSize:12,color:C.muted,margin:"0 0 12px"}}>Compartir, Cualquiera con el link, Lector</p>
              <div style={{display:"flex",gap:8}}>
                <input value={link} onChange={e=>{setLink(e.target.value);setErr("");}}
                  onKeyDown={e=>e.key==="Enter"&&link.trim()&&cargar(link.trim())}
                  placeholder="https://docs.google.com/spreadsheets/d/..."
                  style={{flex:1,padding:"11px 14px",borderRadius:10,border:"1.5px solid "+C.border,fontSize:13,outline:"none",color:C.text,background:C.bg}}/>
                <button onClick={()=>link.trim()&&cargar(link.trim())} disabled={!link.trim()}
                  style={{background:C.accent,color:"white",border:"none",borderRadius:10,padding:"11px 18px",fontWeight:700,cursor:"pointer",fontSize:14,opacity:!link.trim()?0.5:1}}>
                  Cargar
                </button>
              </div>
            </div>
            <div style={{display:"flex",alignItems:"center",gap:10,margin:"4px 0"}}>
              <div style={{flex:1,height:1,background:C.border}}/><span style={{color:C.muted,fontSize:12,fontWeight:600}}>O</span><div style={{flex:1,height:1,background:C.border}}/>
            </div>
            <div onDragOver={e=>{e.preventDefault();setDragging(true);}} onDragLeave={()=>setDragging(false)} onDrop={onDrop}
              onClick={()=>inputRef.current?.click()}
              style={{background:dragging?C.accentL:C.white,borderRadius:14,border:"2.5px dashed "+(dragging?C.accent:C.border),padding:"36px 20px",textAlign:"center",cursor:"pointer",marginTop:12,transition:"all .2s"}}>
              <input ref={inputRef} type="file" accept=".xlsx,.xls,.numbers" style={{display:"none"}}
                onChange={e=>{const f=e.target.files[0];if(f)cargar(f);}}/>
              <div style={{fontSize:38,marginBottom:12}}>[ archivo ]</div>
              <div style={{fontWeight:700,fontSize:15,color:C.text,marginBottom:4}}>Toca para seleccionar archivo</div>
              <div style={{fontSize:12,color:C.muted}}>Excel .xlsx o .xls - detecta Obra Civil automaticamente</div>
              <div style={{fontSize:11,color:C.muted,marginTop:4}}>Nota: archivos .numbers deben exportarse a .xlsx desde Numbers</div>
            </div>
          </>
        )}
      </div>
      <style>{"@keyframes spin{to{transform:rotate(360deg)}}*{box-sizing:border-box;-webkit-font-smoothing:antialiased;-webkit-tap-highlight-color:transparent;}"}</style>
    </div>
  );
}
